package com.DAO;

import com.entity.StateDtls;

public interface StatesDAO {

	    boolean addStates(StateDtls s);
	}

